"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MonitorService = void 0;
var _constants = require("../../common/constants");
var _case_service = require("./case_service");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Monitor Service — background polling for automatic case creation
 */
const CONFIG_DOC_ID = 'monitor_config';
const DEFAULT_CONFIG = {
  enabled: false,
  min_level: 10,
  interval_minutes: 5,
  default_priority: 'P2',
  default_category: 'other',
  last_run_at: null,
  last_processed_timestamp: null,
  cases_created: 0,
  updated_at: new Date().toISOString()
};
class MonitorService {
  // ── Config CRUD ──────────────────────────────────────────────

  static async ensureConfigIndex(client) {
    try {
      const {
        body
      } = await client.indices.exists({
        index: _constants.MONITOR_CONFIG_INDEX
      });
      if (!body) {
        await client.indices.create({
          index: _constants.MONITOR_CONFIG_INDEX,
          body: {
            settings: {
              number_of_shards: 1,
              number_of_replicas: 1
            },
            mappings: {
              properties: {
                enabled: {
                  type: 'boolean'
                },
                min_level: {
                  type: 'integer'
                },
                interval_minutes: {
                  type: 'integer'
                },
                default_priority: {
                  type: 'keyword'
                },
                default_category: {
                  type: 'keyword'
                },
                last_run_at: {
                  type: 'date'
                },
                last_processed_timestamp: {
                  type: 'date'
                },
                cases_created: {
                  type: 'long'
                },
                updated_at: {
                  type: 'date'
                }
              }
            }
          }
        });
      }
    } catch (e) {}
  }
  static async getConfig(client) {
    try {
      const {
        body
      } = await client.get({
        index: _constants.MONITOR_CONFIG_INDEX,
        id: CONFIG_DOC_ID
      });
      return body._source;
    } catch (e) {
      var _e$meta;
      if ((e === null || e === void 0 ? void 0 : e.statusCode) === 404 || (e === null || e === void 0 || (_e$meta = e.meta) === null || _e$meta === void 0 ? void 0 : _e$meta.statusCode) === 404) {
        return {
          ...DEFAULT_CONFIG
        };
      }
      throw e;
    }
  }
  static async saveConfig(client, updates) {
    const existing = await MonitorService.getConfig(client);
    const merged = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString()
    };
    await client.index({
      index: _constants.MONITOR_CONFIG_INDEX,
      id: CONFIG_DOC_ID,
      body: merged,
      refresh: 'wait_for'
    });
    return merged;
  }

  // ── Background Polling ───────────────────────────────────────

  static start(client, logger) {
    if (MonitorService.intervalHandle) return;
    MonitorService.intervalHandle = setInterval(async () => {
      try {
        await MonitorService.tick(client, logger);
      } catch (e) {
        logger.warn(`Monitor tick error: ${e.message}`);
      }
    }, 60_000);
    logger.info('Auto-monitor background job started (checking every 60s)');
  }
  static stop() {
    if (MonitorService.intervalHandle) {
      clearInterval(MonitorService.intervalHandle);
      MonitorService.intervalHandle = null;
    }
  }
  static async tick(client, logger) {
    const config = await MonitorService.getConfig(client);
    if (!config.enabled) return;
    const now = Date.now();
    const intervalMs = (config.interval_minutes || 5) * 60_000;
    const lastRun = config.last_run_at ? new Date(config.last_run_at).getTime() : 0;
    if (now - lastRun < intervalMs) return;
    if (MonitorService.running) return;
    MonitorService.running = true;
    try {
      logger.info(`Auto-monitor: scanning for rule.level >= ${config.min_level}, since=${config.last_processed_timestamp || 'beginning'}`);
      const created = await MonitorService.scanAndCreateCases(client, config, logger);
      await MonitorService.saveConfig(client, {
        last_run_at: new Date().toISOString(),
        cases_created: (config.cases_created || 0) + created
      });
      logger.info(`Auto-monitor: scan done, created=${created}`);
    } finally {
      MonitorService.running = false;
    }
  }

  // ── Alert scanning ───────────────────────────────────────────

  static async scanAndCreateCases(client, config, logger) {
    // Default: look back 24 hours on first run so existing alerts are picked up
    const since = config.last_processed_timestamp || new Date(Date.now() - 24 * 60 * 60_000).toISOString();

    // FIX 1: Wazuh alerts use either "timestamp" or "@timestamp" depending on version.
    // Query both fields with a should clause so alerts are found regardless.
    const searchBody = {
      query: {
        bool: {
          must: [{
            range: {
              'rule.level': {
                gte: Number(config.min_level)
              }
            }
          }],
          should: [{
            range: {
              timestamp: {
                gt: since
              }
            }
          }, {
            range: {
              '@timestamp': {
                gt: since
              }
            }
          }],
          minimum_should_match: 1
        }
      },
      sort: [{
        timestamp: {
          order: 'asc',
          unmapped_type: 'date'
        }
      }],
      size: 100
    };
    let hits = [];
    try {
      var _result$hits;
      const {
        body: result
      } = await client.search({
        index: _constants.WAZUH_ALERTS_INDEX_PATTERN,
        body: searchBody,
        ignore_unavailable: true
      });
      hits = ((_result$hits = result.hits) === null || _result$hits === void 0 ? void 0 : _result$hits.hits) || [];
      logger.info(`Auto-monitor: found ${hits.length} alert(s) with level >= ${config.min_level} since ${since}`);
    } catch (e) {
      logger.warn(`Auto-monitor: alert search failed — ${e.message}`);
      return 0;
    }
    if (hits.length === 0) {
      await MonitorService.saveConfig(client, {
        last_processed_timestamp: new Date().toISOString()
      });
      return 0;
    }
    let created = 0;
    let latestTimestamp = since;

    // FIX 2: Collect alert IDs already linked in open cases so we can deduplicate
    // without relying on custom_fields (which has enabled:false and is not indexed).
    const openCaseAlertIds = await MonitorService.getLinkedAlertIdsFromOpenCases(client, logger);
    for (const hit of hits) {
      var _alert$rule, _alert$rule2, _alert$rule3, _alert$agent;
      const alert = hit._source;
      const alertId = hit._id;

      // Pick timestamp from whichever field exists
      const alertTimestamp = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString();
      if (alertTimestamp > latestTimestamp) latestTimestamp = alertTimestamp;

      // Skip alerts already linked to an open case
      if (openCaseAlertIds.has(alertId)) {
        logger.info(`Auto-monitor: alert ${alertId} already linked — skipping`);
        continue;
      }
      const ruleDescription = (alert === null || alert === void 0 || (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.description) || 'Security Alert';
      const ruleLevel = Number(alert === null || alert === void 0 || (_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.level) || 0;
      const ruleId = String((alert === null || alert === void 0 || (_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.id) || '');
      const agentId = String((alert === null || alert === void 0 || (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id) || '');
      try {
        var _newCase$case_id;
        let severity = 'low';
        if (ruleLevel >= 13) severity = 'critical';else if (ruleLevel >= 10) severity = 'high';else if (ruleLevel >= 7) severity = 'medium';
        const newCase = await _case_service.CaseService.createCase(client, {
          title: 'PLACEHOLDER',
          description: MonitorService.buildDescription(alert, hit._index),
          severity: severity,
          priority: config.default_priority,
          category: config.default_category,
          tags: ['auto-created', `level-${ruleLevel}`, ...(ruleId ? [`rule-${ruleId}`] : [])]
        }, 'auto-monitor');
        const caseDocId = newCase.id;
        const numericSuffix = ((_newCase$case_id = newCase.case_id) === null || _newCase$case_id === void 0 ? void 0 : _newCase$case_id.split('-').pop()) || '0000';
        const prettyTitle = `Wazuh-case-${numericSuffix}: ${ruleDescription}`;
        const linkedAlert = MonitorService.buildLinkedAlert(hit);
        await client.update({
          index: _constants.CASE_INDEX,
          id: caseDocId,
          body: {
            doc: {
              title: prettyTitle,
              linked_alerts: [linkedAlert],
              // FIX 3: store dedup keys as indexed tags instead of custom_fields
              tags: ['auto-created', `level-${ruleLevel}`, `auto-alert-${alertId}`],
              updated_at: new Date().toISOString()
            }
          },
          retry_on_conflict: 3
        });

        // Add to local set so we don't create duplicates within the same scan batch
        openCaseAlertIds.add(alertId);
        created++;
        logger.info(`Auto-monitor: created ${prettyTitle}`);
      } catch (e) {
        logger.warn(`Auto-monitor: failed to process alert ${alertId} — ${e.message}`);
      }
    }
    await MonitorService.saveConfig(client, {
      last_processed_timestamp: latestTimestamp
    });
    return created;
  }

  /**
   * Returns the set of alert IDs already linked inside any open/in-progress/waiting case.
   * Used for deduplication instead of custom_fields (which is not indexed).
   */
  static async getLinkedAlertIdsFromOpenCases(client, logger) {
    const ids = new Set();
    try {
      const {
        body: result
      } = await client.search({
        index: _constants.CASE_INDEX,
        body: {
          query: {
            bool: {
              must: [{
                terms: {
                  status: ['open', 'in_progress', 'waiting']
                }
              }, {
                term: {
                  tags: 'auto-created'
                }
              }]
            }
          },
          _source: ['linked_alerts'],
          size: 500
        }
      });
      for (const hit of ((_result$hits2 = result.hits) === null || _result$hits2 === void 0 ? void 0 : _result$hits2.hits) || []) {
        var _result$hits2;
        for (const la of ((_hit$_source = hit._source) === null || _hit$_source === void 0 ? void 0 : _hit$_source.linked_alerts) || []) {
          var _hit$_source;
          if (la.alert_id) ids.add(la.alert_id);
        }
      }
    } catch (e) {
      logger.warn(`Auto-monitor: could not fetch open case alert IDs — ${e.message}`);
    }
    return ids;
  }
  static buildLinkedAlert(hit) {
    var _alert$rule4, _alert$rule5, _alert$rule6, _alert$rule7, _alert$agent2, _alert$agent3;
    const alert = hit._source;
    return {
      alert_id: hit._id,
      index: hit._index || _constants.WAZUH_ALERTS_INDEX_PATTERN,
      rule_id: parseInt((alert === null || alert === void 0 || (_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.id) || '0', 10),
      rule_description: (alert === null || alert === void 0 || (_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.description) || '',
      rule_level: (alert === null || alert === void 0 || (_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.level) || 0,
      rule_groups: (alert === null || alert === void 0 || (_alert$rule7 = alert.rule) === null || _alert$rule7 === void 0 ? void 0 : _alert$rule7.groups) || [],
      agent_id: (alert === null || alert === void 0 || (_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.id) || '',
      agent_name: (alert === null || alert === void 0 || (_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name) || '',
      timestamp: (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString(),
      full_log: (alert === null || alert === void 0 ? void 0 : alert.full_log) || ''
    };
  }
  static buildDescription(alert, index) {
    var _alert$rule8, _alert$rule9, _alert$rule$level, _alert$rule10, _alert$agent4, _alert$agent5, _alert$rule11;
    const ruleId = (alert === null || alert === void 0 || (_alert$rule8 = alert.rule) === null || _alert$rule8 === void 0 ? void 0 : _alert$rule8.id) || 'N/A';
    const ruleDesc = (alert === null || alert === void 0 || (_alert$rule9 = alert.rule) === null || _alert$rule9 === void 0 ? void 0 : _alert$rule9.description) || 'N/A';
    const ruleLevel = (_alert$rule$level = alert === null || alert === void 0 || (_alert$rule10 = alert.rule) === null || _alert$rule10 === void 0 ? void 0 : _alert$rule10.level) !== null && _alert$rule$level !== void 0 ? _alert$rule$level : 'N/A';
    const agentName = (alert === null || alert === void 0 || (_alert$agent4 = alert.agent) === null || _alert$agent4 === void 0 ? void 0 : _alert$agent4.name) || 'Unknown';
    const agentId = (alert === null || alert === void 0 || (_alert$agent5 = alert.agent) === null || _alert$agent5 === void 0 ? void 0 : _alert$agent5.id) || 'N/A';
    const groups = ((alert === null || alert === void 0 || (_alert$rule11 = alert.rule) === null || _alert$rule11 === void 0 ? void 0 : _alert$rule11.groups) || []).join(', ') || 'N/A';
    const rawTs = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']);
    const timestamp = rawTs ? new Date(rawTs).toLocaleString('en-GB', {
      dateStyle: 'medium',
      timeStyle: 'medium'
    }) : 'N/A';
    const lines = [`This case was automatically created by the Wazuh Case Monitor.`, ``, `## Alert Details`, ``, `- **Rule ID:** ${ruleId}`, `- **Description:** ${ruleDesc}`, `- **Level:** ${ruleLevel}`, `- **Groups:** ${groups}`, `- **Agent:** ${agentName} (ID: ${agentId})`, `- **Detected:** ${timestamp}`];
    if (alert !== null && alert !== void 0 && alert.full_log) {
      const log = String(alert.full_log).trim().substring(0, 600);
      lines.push(``, `## Raw Log`, ``, `\`\`\``, log, `\`\`\``);
    }
    return lines.join('\n');
  }
}
exports.MonitorService = MonitorService;
_defineProperty(MonitorService, "intervalHandle", null);
_defineProperty(MonitorService, "running", false);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfZGVmaW5lUHJvcGVydHkiLCJlIiwiciIsInQiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJpIiwiX3RvUHJpbWl0aXZlIiwiU3ltYm9sIiwidG9QcmltaXRpdmUiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiTnVtYmVyIiwiQ09ORklHX0RPQ19JRCIsIkRFRkFVTFRfQ09ORklHIiwiZW5hYmxlZCIsIm1pbl9sZXZlbCIsImludGVydmFsX21pbnV0ZXMiLCJkZWZhdWx0X3ByaW9yaXR5IiwiZGVmYXVsdF9jYXRlZ29yeSIsImxhc3RfcnVuX2F0IiwibGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wIiwiY2FzZXNfY3JlYXRlZCIsInVwZGF0ZWRfYXQiLCJEYXRlIiwidG9JU09TdHJpbmciLCJNb25pdG9yU2VydmljZSIsImVuc3VyZUNvbmZpZ0luZGV4IiwiY2xpZW50IiwiYm9keSIsImluZGljZXMiLCJleGlzdHMiLCJpbmRleCIsIk1PTklUT1JfQ09ORklHX0lOREVYIiwiY3JlYXRlIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwibnVtYmVyX29mX3JlcGxpY2FzIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwidHlwZSIsImdldENvbmZpZyIsImdldCIsImlkIiwiX3NvdXJjZSIsIl9lJG1ldGEiLCJzdGF0dXNDb2RlIiwibWV0YSIsInNhdmVDb25maWciLCJ1cGRhdGVzIiwiZXhpc3RpbmciLCJtZXJnZWQiLCJyZWZyZXNoIiwic3RhcnQiLCJsb2dnZXIiLCJpbnRlcnZhbEhhbmRsZSIsInNldEludGVydmFsIiwidGljayIsIndhcm4iLCJtZXNzYWdlIiwiaW5mbyIsInN0b3AiLCJjbGVhckludGVydmFsIiwiY29uZmlnIiwibm93IiwiaW50ZXJ2YWxNcyIsImxhc3RSdW4iLCJnZXRUaW1lIiwicnVubmluZyIsImNyZWF0ZWQiLCJzY2FuQW5kQ3JlYXRlQ2FzZXMiLCJzaW5jZSIsInNlYXJjaEJvZHkiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwicmFuZ2UiLCJndGUiLCJzaG91bGQiLCJ0aW1lc3RhbXAiLCJndCIsIm1pbmltdW1fc2hvdWxkX21hdGNoIiwic29ydCIsIm9yZGVyIiwidW5tYXBwZWRfdHlwZSIsInNpemUiLCJoaXRzIiwiX3Jlc3VsdCRoaXRzIiwicmVzdWx0Iiwic2VhcmNoIiwiV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4iLCJpZ25vcmVfdW5hdmFpbGFibGUiLCJsZW5ndGgiLCJsYXRlc3RUaW1lc3RhbXAiLCJvcGVuQ2FzZUFsZXJ0SWRzIiwiZ2V0TGlua2VkQWxlcnRJZHNGcm9tT3BlbkNhc2VzIiwiaGl0IiwiX2FsZXJ0JHJ1bGUiLCJfYWxlcnQkcnVsZTIiLCJfYWxlcnQkcnVsZTMiLCJfYWxlcnQkYWdlbnQiLCJhbGVydCIsImFsZXJ0SWQiLCJfaWQiLCJhbGVydFRpbWVzdGFtcCIsImhhcyIsInJ1bGVEZXNjcmlwdGlvbiIsInJ1bGUiLCJkZXNjcmlwdGlvbiIsInJ1bGVMZXZlbCIsImxldmVsIiwicnVsZUlkIiwiYWdlbnRJZCIsImFnZW50IiwiX25ld0Nhc2UkY2FzZV9pZCIsInNldmVyaXR5IiwibmV3Q2FzZSIsIkNhc2VTZXJ2aWNlIiwiY3JlYXRlQ2FzZSIsInRpdGxlIiwiYnVpbGREZXNjcmlwdGlvbiIsIl9pbmRleCIsInByaW9yaXR5IiwiY2F0ZWdvcnkiLCJ0YWdzIiwiY2FzZURvY0lkIiwibnVtZXJpY1N1ZmZpeCIsImNhc2VfaWQiLCJzcGxpdCIsInBvcCIsInByZXR0eVRpdGxlIiwibGlua2VkQWxlcnQiLCJidWlsZExpbmtlZEFsZXJ0IiwidXBkYXRlIiwiQ0FTRV9JTkRFWCIsImRvYyIsImxpbmtlZF9hbGVydHMiLCJyZXRyeV9vbl9jb25mbGljdCIsImFkZCIsImlkcyIsIlNldCIsInRlcm1zIiwic3RhdHVzIiwidGVybSIsIl9yZXN1bHQkaGl0czIiLCJsYSIsIl9oaXQkX3NvdXJjZSIsImFsZXJ0X2lkIiwiX2FsZXJ0JHJ1bGU0IiwiX2FsZXJ0JHJ1bGU1IiwiX2FsZXJ0JHJ1bGU2IiwiX2FsZXJ0JHJ1bGU3IiwiX2FsZXJ0JGFnZW50MiIsIl9hbGVydCRhZ2VudDMiLCJydWxlX2lkIiwicGFyc2VJbnQiLCJydWxlX2Rlc2NyaXB0aW9uIiwicnVsZV9sZXZlbCIsInJ1bGVfZ3JvdXBzIiwiZ3JvdXBzIiwiYWdlbnRfaWQiLCJhZ2VudF9uYW1lIiwibmFtZSIsImZ1bGxfbG9nIiwiX2FsZXJ0JHJ1bGU4IiwiX2FsZXJ0JHJ1bGU5IiwiX2FsZXJ0JHJ1bGUkbGV2ZWwiLCJfYWxlcnQkcnVsZTEwIiwiX2FsZXJ0JGFnZW50NCIsIl9hbGVydCRhZ2VudDUiLCJfYWxlcnQkcnVsZTExIiwicnVsZURlc2MiLCJhZ2VudE5hbWUiLCJqb2luIiwicmF3VHMiLCJ0b0xvY2FsZVN0cmluZyIsImRhdGVTdHlsZSIsInRpbWVTdHlsZSIsImxpbmVzIiwibG9nIiwidHJpbSIsInN1YnN0cmluZyIsInB1c2giLCJleHBvcnRzIl0sInNvdXJjZXMiOlsibW9uaXRvcl9zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBNb25pdG9yIFNlcnZpY2Ug4oCUIGJhY2tncm91bmQgcG9sbGluZyBmb3IgYXV0b21hdGljIGNhc2UgY3JlYXRpb25cbiAqL1xuXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgTU9OSVRPUl9DT05GSUdfSU5ERVgsIFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLCBDQVNFX0lOREVYIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBDYXNlU2VydmljZSB9IGZyb20gJy4vY2FzZV9zZXJ2aWNlJztcblxuZXhwb3J0IGludGVyZmFjZSBNb25pdG9yQ29uZmlnIHtcbiAgZW5hYmxlZDogYm9vbGVhbjtcbiAgbWluX2xldmVsOiBudW1iZXI7XG4gIGludGVydmFsX21pbnV0ZXM6IG51bWJlcjtcbiAgZGVmYXVsdF9wcmlvcml0eTogc3RyaW5nO1xuICBkZWZhdWx0X2NhdGVnb3J5OiBzdHJpbmc7XG4gIGxhc3RfcnVuX2F0OiBzdHJpbmcgfCBudWxsO1xuICBsYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXA6IHN0cmluZyB8IG51bGw7XG4gIGNhc2VzX2NyZWF0ZWQ6IG51bWJlcjtcbiAgdXBkYXRlZF9hdDogc3RyaW5nO1xufVxuXG5jb25zdCBDT05GSUdfRE9DX0lEID0gJ21vbml0b3JfY29uZmlnJztcblxuY29uc3QgREVGQVVMVF9DT05GSUc6IE1vbml0b3JDb25maWcgPSB7XG4gIGVuYWJsZWQ6IGZhbHNlLFxuICBtaW5fbGV2ZWw6IDEwLFxuICBpbnRlcnZhbF9taW51dGVzOiA1LFxuICBkZWZhdWx0X3ByaW9yaXR5OiAnUDInLFxuICBkZWZhdWx0X2NhdGVnb3J5OiAnb3RoZXInLFxuICBsYXN0X3J1bl9hdDogbnVsbCxcbiAgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiBudWxsLFxuICBjYXNlc19jcmVhdGVkOiAwLFxuICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG59O1xuXG5leHBvcnQgY2xhc3MgTW9uaXRvclNlcnZpY2Uge1xuICBwcml2YXRlIHN0YXRpYyBpbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgc3RhdGljIHJ1bm5pbmcgPSBmYWxzZTtcblxuICAvLyDilIDilIAgQ29uZmlnIENSVUQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgc3RhdGljIGFzeW5jIGVuc3VyZUNvbmZpZ0luZGV4KGNsaWVudDogYW55KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keSB9ID0gYXdhaXQgY2xpZW50LmluZGljZXMuZXhpc3RzKHsgaW5kZXg6IE1PTklUT1JfQ09ORklHX0lOREVYIH0pO1xuICAgICAgaWYgKCFib2R5KSB7XG4gICAgICAgIGF3YWl0IGNsaWVudC5pbmRpY2VzLmNyZWF0ZSh7XG4gICAgICAgICAgaW5kZXg6IE1PTklUT1JfQ09ORklHX0lOREVYLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHNldHRpbmdzOiB7IG51bWJlcl9vZl9zaGFyZHM6IDEsIG51bWJlcl9vZl9yZXBsaWNhczogMSB9LFxuICAgICAgICAgICAgbWFwcGluZ3M6IHtcbiAgICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHsgdHlwZTogJ2Jvb2xlYW4nIH0sXG4gICAgICAgICAgICAgICAgbWluX2xldmVsOiB7IHR5cGU6ICdpbnRlZ2VyJyB9LFxuICAgICAgICAgICAgICAgIGludGVydmFsX21pbnV0ZXM6IHsgdHlwZTogJ2ludGVnZXInIH0sXG4gICAgICAgICAgICAgICAgZGVmYXVsdF9wcmlvcml0eTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICAgICAgICBkZWZhdWx0X2NhdGVnb3J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgICAgICAgIGxhc3RfcnVuX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgICAgICAgIGxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICAgICAgICBjYXNlc19jcmVhdGVkOiB7IHR5cGU6ICdsb25nJyB9LFxuICAgICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHt9XG4gIH1cblxuICBzdGF0aWMgYXN5bmMgZ2V0Q29uZmlnKGNsaWVudDogYW55KTogUHJvbWlzZTxNb25pdG9yQ29uZmlnPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keSB9ID0gYXdhaXQgY2xpZW50LmdldCh7IGluZGV4OiBNT05JVE9SX0NPTkZJR19JTkRFWCwgaWQ6IENPTkZJR19ET0NfSUQgfSk7XG4gICAgICByZXR1cm4gYm9keS5fc291cmNlIGFzIE1vbml0b3JDb25maWc7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBpZiAoZT8uc3RhdHVzQ29kZSA9PT0gNDA0IHx8IGU/Lm1ldGE/LnN0YXR1c0NvZGUgPT09IDQwNCkge1xuICAgICAgICByZXR1cm4geyAuLi5ERUZBVUxUX0NPTkZJRyB9O1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH1cblxuICBzdGF0aWMgYXN5bmMgc2F2ZUNvbmZpZyhjbGllbnQ6IGFueSwgdXBkYXRlczogUGFydGlhbDxNb25pdG9yQ29uZmlnPik6IFByb21pc2U8TW9uaXRvckNvbmZpZz4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgTW9uaXRvclNlcnZpY2UuZ2V0Q29uZmlnKGNsaWVudCk7XG4gICAgY29uc3QgbWVyZ2VkOiBNb25pdG9yQ29uZmlnID0geyAuLi5leGlzdGluZywgLi4udXBkYXRlcywgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH07XG4gICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgIGluZGV4OiBNT05JVE9SX0NPTkZJR19JTkRFWCxcbiAgICAgIGlkOiBDT05GSUdfRE9DX0lELFxuICAgICAgYm9keTogbWVyZ2VkLFxuICAgICAgcmVmcmVzaDogJ3dhaXRfZm9yJyxcbiAgICB9KTtcbiAgICByZXR1cm4gbWVyZ2VkO1xuICB9XG5cbiAgLy8g4pSA4pSAIEJhY2tncm91bmQgUG9sbGluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBzdGF0aWMgc3RhcnQoY2xpZW50OiBhbnksIGxvZ2dlcjogTG9nZ2VyKTogdm9pZCB7XG4gICAgaWYgKE1vbml0b3JTZXJ2aWNlLmludGVydmFsSGFuZGxlKSByZXR1cm47XG4gICAgTW9uaXRvclNlcnZpY2UuaW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbChhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBNb25pdG9yU2VydmljZS50aWNrKGNsaWVudCwgbG9nZ2VyKTtcbiAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICBsb2dnZXIud2FybihgTW9uaXRvciB0aWNrIGVycm9yOiAke2UubWVzc2FnZX1gKTtcbiAgICAgIH1cbiAgICB9LCA2MF8wMDApO1xuICAgIGxvZ2dlci5pbmZvKCdBdXRvLW1vbml0b3IgYmFja2dyb3VuZCBqb2Igc3RhcnRlZCAoY2hlY2tpbmcgZXZlcnkgNjBzKScpO1xuICB9XG5cbiAgc3RhdGljIHN0b3AoKTogdm9pZCB7XG4gICAgaWYgKE1vbml0b3JTZXJ2aWNlLmludGVydmFsSGFuZGxlKSB7XG4gICAgICBjbGVhckludGVydmFsKE1vbml0b3JTZXJ2aWNlLmludGVydmFsSGFuZGxlKTtcbiAgICAgIE1vbml0b3JTZXJ2aWNlLmludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICBzdGF0aWMgYXN5bmMgdGljayhjbGllbnQ6IGFueSwgbG9nZ2VyOiBMb2dnZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBjb25maWcgPSBhd2FpdCBNb25pdG9yU2VydmljZS5nZXRDb25maWcoY2xpZW50KTtcbiAgICBpZiAoIWNvbmZpZy5lbmFibGVkKSByZXR1cm47XG5cbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IGludGVydmFsTXMgPSAoY29uZmlnLmludGVydmFsX21pbnV0ZXMgfHwgNSkgKiA2MF8wMDA7XG4gICAgY29uc3QgbGFzdFJ1biA9IGNvbmZpZy5sYXN0X3J1bl9hdCA/IG5ldyBEYXRlKGNvbmZpZy5sYXN0X3J1bl9hdCkuZ2V0VGltZSgpIDogMDtcbiAgICBpZiAobm93IC0gbGFzdFJ1biA8IGludGVydmFsTXMpIHJldHVybjtcblxuICAgIGlmIChNb25pdG9yU2VydmljZS5ydW5uaW5nKSByZXR1cm47XG4gICAgTW9uaXRvclNlcnZpY2UucnVubmluZyA9IHRydWU7XG5cbiAgICB0cnkge1xuICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogc2Nhbm5pbmcgZm9yIHJ1bGUubGV2ZWwgPj0gJHtjb25maWcubWluX2xldmVsfSwgc2luY2U9JHtjb25maWcubGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wIHx8ICdiZWdpbm5pbmcnfWApO1xuICAgICAgY29uc3QgY3JlYXRlZCA9IGF3YWl0IE1vbml0b3JTZXJ2aWNlLnNjYW5BbmRDcmVhdGVDYXNlcyhjbGllbnQsIGNvbmZpZywgbG9nZ2VyKTtcbiAgICAgIGF3YWl0IE1vbml0b3JTZXJ2aWNlLnNhdmVDb25maWcoY2xpZW50LCB7XG4gICAgICAgIGxhc3RfcnVuX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGNhc2VzX2NyZWF0ZWQ6IChjb25maWcuY2FzZXNfY3JlYXRlZCB8fCAwKSArIGNyZWF0ZWQsXG4gICAgICB9KTtcbiAgICAgIGxvZ2dlci5pbmZvKGBBdXRvLW1vbml0b3I6IHNjYW4gZG9uZSwgY3JlYXRlZD0ke2NyZWF0ZWR9YCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIE1vbml0b3JTZXJ2aWNlLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICAvLyDilIDilIAgQWxlcnQgc2Nhbm5pbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgc3RhdGljIGFzeW5jIHNjYW5BbmRDcmVhdGVDYXNlcyhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjb25maWc6IE1vbml0b3JDb25maWcsXG4gICAgbG9nZ2VyOiBMb2dnZXIsXG4gICk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgLy8gRGVmYXVsdDogbG9vayBiYWNrIDI0IGhvdXJzIG9uIGZpcnN0IHJ1biBzbyBleGlzdGluZyBhbGVydHMgYXJlIHBpY2tlZCB1cFxuICAgIGNvbnN0IHNpbmNlID0gY29uZmlnLmxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcFxuICAgICAgfHwgbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0ICogNjAgKiA2MF8wMDApLnRvSVNPU3RyaW5nKCk7XG5cbiAgICAvLyBGSVggMTogV2F6dWggYWxlcnRzIHVzZSBlaXRoZXIgXCJ0aW1lc3RhbXBcIiBvciBcIkB0aW1lc3RhbXBcIiBkZXBlbmRpbmcgb24gdmVyc2lvbi5cbiAgICAvLyBRdWVyeSBib3RoIGZpZWxkcyB3aXRoIGEgc2hvdWxkIGNsYXVzZSBzbyBhbGVydHMgYXJlIGZvdW5kIHJlZ2FyZGxlc3MuXG4gICAgY29uc3Qgc2VhcmNoQm9keSA9IHtcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIGJvb2w6IHtcbiAgICAgICAgICBtdXN0OiBbXG4gICAgICAgICAgICB7IHJhbmdlOiB7ICdydWxlLmxldmVsJzogeyBndGU6IE51bWJlcihjb25maWcubWluX2xldmVsKSB9IH0gfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNob3VsZDogW1xuICAgICAgICAgICAgeyByYW5nZTogeyB0aW1lc3RhbXA6ICAgeyBndDogc2luY2UgfSB9IH0sXG4gICAgICAgICAgICB7IHJhbmdlOiB7ICdAdGltZXN0YW1wJzogeyBndDogc2luY2UgfSB9IH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBtaW5pbXVtX3Nob3VsZF9tYXRjaDogMSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBzb3J0OiBbXG4gICAgICAgIHsgdGltZXN0YW1wOiB7IG9yZGVyOiAnYXNjJywgdW5tYXBwZWRfdHlwZTogJ2RhdGUnIH0gfSxcbiAgICAgIF0sXG4gICAgICBzaXplOiAxMDAsXG4gICAgfTtcblxuICAgIGxldCBoaXRzOiBhbnlbXSA9IFtdO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGJvZHk6IHJlc3VsdCB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgIGluZGV4OiBXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTixcbiAgICAgICAgYm9keTogc2VhcmNoQm9keSxcbiAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgfSk7XG4gICAgICBoaXRzID0gcmVzdWx0LmhpdHM/LmhpdHMgfHwgW107XG4gICAgICBsb2dnZXIuaW5mbyhgQXV0by1tb25pdG9yOiBmb3VuZCAke2hpdHMubGVuZ3RofSBhbGVydChzKSB3aXRoIGxldmVsID49ICR7Y29uZmlnLm1pbl9sZXZlbH0gc2luY2UgJHtzaW5jZX1gKTtcbiAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgIGxvZ2dlci53YXJuKGBBdXRvLW1vbml0b3I6IGFsZXJ0IHNlYXJjaCBmYWlsZWQg4oCUICR7ZS5tZXNzYWdlfWApO1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgaWYgKGhpdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBNb25pdG9yU2VydmljZS5zYXZlQ29uZmlnKGNsaWVudCwge1xuICAgICAgICBsYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgbGV0IGNyZWF0ZWQgPSAwO1xuICAgIGxldCBsYXRlc3RUaW1lc3RhbXAgPSBzaW5jZTtcblxuICAgIC8vIEZJWCAyOiBDb2xsZWN0IGFsZXJ0IElEcyBhbHJlYWR5IGxpbmtlZCBpbiBvcGVuIGNhc2VzIHNvIHdlIGNhbiBkZWR1cGxpY2F0ZVxuICAgIC8vIHdpdGhvdXQgcmVseWluZyBvbiBjdXN0b21fZmllbGRzICh3aGljaCBoYXMgZW5hYmxlZDpmYWxzZSBhbmQgaXMgbm90IGluZGV4ZWQpLlxuICAgIGNvbnN0IG9wZW5DYXNlQWxlcnRJZHMgPSBhd2FpdCBNb25pdG9yU2VydmljZS5nZXRMaW5rZWRBbGVydElkc0Zyb21PcGVuQ2FzZXMoY2xpZW50LCBsb2dnZXIpO1xuXG4gICAgZm9yIChjb25zdCBoaXQgb2YgaGl0cykge1xuICAgICAgY29uc3QgYWxlcnQgPSBoaXQuX3NvdXJjZTtcbiAgICAgIGNvbnN0IGFsZXJ0SWQgPSBoaXQuX2lkO1xuXG4gICAgICAvLyBQaWNrIHRpbWVzdGFtcCBmcm9tIHdoaWNoZXZlciBmaWVsZCBleGlzdHNcbiAgICAgIGNvbnN0IGFsZXJ0VGltZXN0YW1wOiBzdHJpbmcgPVxuICAgICAgICBhbGVydD8udGltZXN0YW1wIHx8IGFsZXJ0Py5bJ0B0aW1lc3RhbXAnXSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgICAgIGlmIChhbGVydFRpbWVzdGFtcCA+IGxhdGVzdFRpbWVzdGFtcCkgbGF0ZXN0VGltZXN0YW1wID0gYWxlcnRUaW1lc3RhbXA7XG5cbiAgICAgIC8vIFNraXAgYWxlcnRzIGFscmVhZHkgbGlua2VkIHRvIGFuIG9wZW4gY2FzZVxuICAgICAgaWYgKG9wZW5DYXNlQWxlcnRJZHMuaGFzKGFsZXJ0SWQpKSB7XG4gICAgICAgIGxvZ2dlci5pbmZvKGBBdXRvLW1vbml0b3I6IGFsZXJ0ICR7YWxlcnRJZH0gYWxyZWFkeSBsaW5rZWQg4oCUIHNraXBwaW5nYCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBydWxlRGVzY3JpcHRpb24gPSBhbGVydD8ucnVsZT8uZGVzY3JpcHRpb24gfHwgJ1NlY3VyaXR5IEFsZXJ0JztcbiAgICAgIGNvbnN0IHJ1bGVMZXZlbCAgICAgICA9IE51bWJlcihhbGVydD8ucnVsZT8ubGV2ZWwpIHx8IDA7XG4gICAgICBjb25zdCBydWxlSWQgICAgICAgICAgPSBTdHJpbmcoYWxlcnQ/LnJ1bGU/LmlkIHx8ICcnKTtcbiAgICAgIGNvbnN0IGFnZW50SWQgICAgICAgICA9IFN0cmluZyhhbGVydD8uYWdlbnQ/LmlkIHx8ICcnKTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgbGV0IHNldmVyaXR5ID0gJ2xvdyc7XG4gICAgICAgIGlmIChydWxlTGV2ZWwgPj0gMTMpIHNldmVyaXR5ID0gJ2NyaXRpY2FsJztcbiAgICAgICAgZWxzZSBpZiAocnVsZUxldmVsID49IDEwKSBzZXZlcml0eSA9ICdoaWdoJztcbiAgICAgICAgZWxzZSBpZiAocnVsZUxldmVsID49IDcpICBzZXZlcml0eSA9ICdtZWRpdW0nO1xuXG4gICAgICAgIGNvbnN0IG5ld0Nhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5jcmVhdGVDYXNlKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogJ1BMQUNFSE9MREVSJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBNb25pdG9yU2VydmljZS5idWlsZERlc2NyaXB0aW9uKGFsZXJ0LCBoaXQuX2luZGV4KSxcbiAgICAgICAgICAgIHNldmVyaXR5OiBzZXZlcml0eSBhcyBhbnksXG4gICAgICAgICAgICBwcmlvcml0eTogY29uZmlnLmRlZmF1bHRfcHJpb3JpdHkgYXMgYW55LFxuICAgICAgICAgICAgY2F0ZWdvcnk6IGNvbmZpZy5kZWZhdWx0X2NhdGVnb3J5IGFzIGFueSxcbiAgICAgICAgICAgIHRhZ3M6IFsnYXV0by1jcmVhdGVkJywgYGxldmVsLSR7cnVsZUxldmVsfWAsIC4uLihydWxlSWQgPyBbYHJ1bGUtJHtydWxlSWR9YF0gOiBbXSldLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgJ2F1dG8tbW9uaXRvcicsXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgY2FzZURvY0lkICAgICAgPSBuZXdDYXNlLmlkITtcbiAgICAgICAgY29uc3QgbnVtZXJpY1N1ZmZpeCAgPSBuZXdDYXNlLmNhc2VfaWQ/LnNwbGl0KCctJykucG9wKCkgfHwgJzAwMDAnO1xuICAgICAgICBjb25zdCBwcmV0dHlUaXRsZSAgICA9IGBXYXp1aC1jYXNlLSR7bnVtZXJpY1N1ZmZpeH06ICR7cnVsZURlc2NyaXB0aW9ufWA7XG4gICAgICAgIGNvbnN0IGxpbmtlZEFsZXJ0ICAgID0gTW9uaXRvclNlcnZpY2UuYnVpbGRMaW5rZWRBbGVydChoaXQpO1xuXG4gICAgICAgIGF3YWl0IGNsaWVudC51cGRhdGUoe1xuICAgICAgICAgIGluZGV4OiBDQVNFX0lOREVYLFxuICAgICAgICAgIGlkOiBjYXNlRG9jSWQsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgZG9jOiB7XG4gICAgICAgICAgICAgIHRpdGxlOiBwcmV0dHlUaXRsZSxcbiAgICAgICAgICAgICAgbGlua2VkX2FsZXJ0czogW2xpbmtlZEFsZXJ0XSxcbiAgICAgICAgICAgICAgLy8gRklYIDM6IHN0b3JlIGRlZHVwIGtleXMgYXMgaW5kZXhlZCB0YWdzIGluc3RlYWQgb2YgY3VzdG9tX2ZpZWxkc1xuICAgICAgICAgICAgICB0YWdzOiBbJ2F1dG8tY3JlYXRlZCcsIGBsZXZlbC0ke3J1bGVMZXZlbH1gLCBgYXV0by1hbGVydC0ke2FsZXJ0SWR9YF0sXG4gICAgICAgICAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXRyeV9vbl9jb25mbGljdDogMyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gQWRkIHRvIGxvY2FsIHNldCBzbyB3ZSBkb24ndCBjcmVhdGUgZHVwbGljYXRlcyB3aXRoaW4gdGhlIHNhbWUgc2NhbiBiYXRjaFxuICAgICAgICBvcGVuQ2FzZUFsZXJ0SWRzLmFkZChhbGVydElkKTtcblxuICAgICAgICBjcmVhdGVkKys7XG4gICAgICAgIGxvZ2dlci5pbmZvKGBBdXRvLW1vbml0b3I6IGNyZWF0ZWQgJHtwcmV0dHlUaXRsZX1gKTtcbiAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICBsb2dnZXIud2FybihgQXV0by1tb25pdG9yOiBmYWlsZWQgdG8gcHJvY2VzcyBhbGVydCAke2FsZXJ0SWR9IOKAlCAke2UubWVzc2FnZX1gKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBhd2FpdCBNb25pdG9yU2VydmljZS5zYXZlQ29uZmlnKGNsaWVudCwge1xuICAgICAgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiBsYXRlc3RUaW1lc3RhbXAsXG4gICAgfSk7XG5cbiAgICByZXR1cm4gY3JlYXRlZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzZXQgb2YgYWxlcnQgSURzIGFscmVhZHkgbGlua2VkIGluc2lkZSBhbnkgb3Blbi9pbi1wcm9ncmVzcy93YWl0aW5nIGNhc2UuXG4gICAqIFVzZWQgZm9yIGRlZHVwbGljYXRpb24gaW5zdGVhZCBvZiBjdXN0b21fZmllbGRzICh3aGljaCBpcyBub3QgaW5kZXhlZCkuXG4gICAqL1xuICBwcml2YXRlIHN0YXRpYyBhc3luYyBnZXRMaW5rZWRBbGVydElkc0Zyb21PcGVuQ2FzZXMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgbG9nZ2VyOiBMb2dnZXIsXG4gICk6IFByb21pc2U8U2V0PHN0cmluZz4+IHtcbiAgICBjb25zdCBpZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5OiByZXN1bHQgfSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICBpbmRleDogQ0FTRV9JTkRFWCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgIG11c3Q6IFtcbiAgICAgICAgICAgICAgICB7IHRlcm1zOiB7IHN0YXR1czogWydvcGVuJywgJ2luX3Byb2dyZXNzJywgJ3dhaXRpbmcnXSB9IH0sXG4gICAgICAgICAgICAgICAgeyB0ZXJtOiB7IHRhZ3M6ICdhdXRvLWNyZWF0ZWQnIH0gfSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBfc291cmNlOiBbJ2xpbmtlZF9hbGVydHMnXSxcbiAgICAgICAgICBzaXplOiA1MDAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIGZvciAoY29uc3QgaGl0IG9mIChyZXN1bHQuaGl0cz8uaGl0cyB8fCBbXSkpIHtcbiAgICAgICAgZm9yIChjb25zdCBsYSBvZiAoaGl0Ll9zb3VyY2U/LmxpbmtlZF9hbGVydHMgfHwgW10pKSB7XG4gICAgICAgICAgaWYgKGxhLmFsZXJ0X2lkKSBpZHMuYWRkKGxhLmFsZXJ0X2lkKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgbG9nZ2VyLndhcm4oYEF1dG8tbW9uaXRvcjogY291bGQgbm90IGZldGNoIG9wZW4gY2FzZSBhbGVydCBJRHMg4oCUICR7ZS5tZXNzYWdlfWApO1xuICAgIH1cbiAgICByZXR1cm4gaWRzO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgYnVpbGRMaW5rZWRBbGVydChoaXQ6IGFueSk6IGFueSB7XG4gICAgY29uc3QgYWxlcnQgPSBoaXQuX3NvdXJjZTtcbiAgICByZXR1cm4ge1xuICAgICAgYWxlcnRfaWQ6ICAgICAgICAgaGl0Ll9pZCxcbiAgICAgIGluZGV4OiAgICAgICAgICAgIGhpdC5faW5kZXggfHwgV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sXG4gICAgICBydWxlX2lkOiAgICAgICAgICBwYXJzZUludChhbGVydD8ucnVsZT8uaWQgfHwgJzAnLCAxMCksXG4gICAgICBydWxlX2Rlc2NyaXB0aW9uOiBhbGVydD8ucnVsZT8uZGVzY3JpcHRpb24gfHwgJycsXG4gICAgICBydWxlX2xldmVsOiAgICAgICBhbGVydD8ucnVsZT8ubGV2ZWwgfHwgMCxcbiAgICAgIHJ1bGVfZ3JvdXBzOiAgICAgIGFsZXJ0Py5ydWxlPy5ncm91cHMgfHwgW10sXG4gICAgICBhZ2VudF9pZDogICAgICAgICBhbGVydD8uYWdlbnQ/LmlkIHx8ICcnLFxuICAgICAgYWdlbnRfbmFtZTogICAgICAgYWxlcnQ/LmFnZW50Py5uYW1lIHx8ICcnLFxuICAgICAgdGltZXN0YW1wOiAgICAgICAgYWxlcnQ/LnRpbWVzdGFtcCB8fCBhbGVydD8uWydAdGltZXN0YW1wJ10gfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZnVsbF9sb2c6ICAgICAgICAgYWxlcnQ/LmZ1bGxfbG9nIHx8ICcnLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBidWlsZERlc2NyaXB0aW9uKGFsZXJ0OiBhbnksIGluZGV4OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHJ1bGVJZCAgICA9IGFsZXJ0Py5ydWxlPy5pZCB8fCAnTi9BJztcbiAgICBjb25zdCBydWxlRGVzYyAgPSBhbGVydD8ucnVsZT8uZGVzY3JpcHRpb24gfHwgJ04vQSc7XG4gICAgY29uc3QgcnVsZUxldmVsID0gYWxlcnQ/LnJ1bGU/LmxldmVsID8/ICdOL0EnO1xuICAgIGNvbnN0IGFnZW50TmFtZSA9IGFsZXJ0Py5hZ2VudD8ubmFtZSB8fCAnVW5rbm93bic7XG4gICAgY29uc3QgYWdlbnRJZCAgID0gYWxlcnQ/LmFnZW50Py5pZCB8fCAnTi9BJztcbiAgICBjb25zdCBncm91cHMgICAgPSAoYWxlcnQ/LnJ1bGU/Lmdyb3VwcyB8fCBbXSkuam9pbignLCAnKSB8fCAnTi9BJztcbiAgICBjb25zdCByYXdUcyAgICAgPSBhbGVydD8udGltZXN0YW1wIHx8IGFsZXJ0Py5bJ0B0aW1lc3RhbXAnXTtcbiAgICBjb25zdCB0aW1lc3RhbXAgPSByYXdUc1xuICAgICAgPyBuZXcgRGF0ZShyYXdUcykudG9Mb2NhbGVTdHJpbmcoJ2VuLUdCJywgeyBkYXRlU3R5bGU6ICdtZWRpdW0nLCB0aW1lU3R5bGU6ICdtZWRpdW0nIH0pXG4gICAgICA6ICdOL0EnO1xuXG4gICAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW1xuICAgICAgYFRoaXMgY2FzZSB3YXMgYXV0b21hdGljYWxseSBjcmVhdGVkIGJ5IHRoZSBXYXp1aCBDYXNlIE1vbml0b3IuYCxcbiAgICAgIGBgLFxuICAgICAgYCMjIEFsZXJ0IERldGFpbHNgLFxuICAgICAgYGAsXG4gICAgICBgLSAqKlJ1bGUgSUQ6KiogJHtydWxlSWR9YCxcbiAgICAgIGAtICoqRGVzY3JpcHRpb246KiogJHtydWxlRGVzY31gLFxuICAgICAgYC0gKipMZXZlbDoqKiAke3J1bGVMZXZlbH1gLFxuICAgICAgYC0gKipHcm91cHM6KiogJHtncm91cHN9YCxcbiAgICAgIGAtICoqQWdlbnQ6KiogJHthZ2VudE5hbWV9IChJRDogJHthZ2VudElkfSlgLFxuICAgICAgYC0gKipEZXRlY3RlZDoqKiAke3RpbWVzdGFtcH1gLFxuICAgIF07XG5cbiAgICBpZiAoYWxlcnQ/LmZ1bGxfbG9nKSB7XG4gICAgICBjb25zdCBsb2cgPSBTdHJpbmcoYWxlcnQuZnVsbF9sb2cpLnRyaW0oKS5zdWJzdHJpbmcoMCwgNjAwKTtcbiAgICAgIGxpbmVzLnB1c2goYGAsIGAjIyBSYXcgTG9nYCwgYGAsIGBcXGBcXGBcXGBgLCBsb2csIGBcXGBcXGBcXGBgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbGluZXMuam9pbignXFxuJyk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBQTZDLFNBQUFFLGdCQUFBQyxDQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQSxZQUFBRCxDQUFBLEdBQUFFLGNBQUEsQ0FBQUYsQ0FBQSxNQUFBRCxDQUFBLEdBQUFJLE1BQUEsQ0FBQUMsY0FBQSxDQUFBTCxDQUFBLEVBQUFDLENBQUEsSUFBQUssS0FBQSxFQUFBSixDQUFBLEVBQUFLLFVBQUEsTUFBQUMsWUFBQSxNQUFBQyxRQUFBLFVBQUFULENBQUEsQ0FBQUMsQ0FBQSxJQUFBQyxDQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyxlQUFBRCxDQUFBLFFBQUFRLENBQUEsR0FBQUMsWUFBQSxDQUFBVCxDQUFBLHVDQUFBUSxDQUFBLEdBQUFBLENBQUEsR0FBQUEsQ0FBQTtBQUFBLFNBQUFDLGFBQUFULENBQUEsRUFBQUQsQ0FBQSwyQkFBQUMsQ0FBQSxLQUFBQSxDQUFBLFNBQUFBLENBQUEsTUFBQUYsQ0FBQSxHQUFBRSxDQUFBLENBQUFVLE1BQUEsQ0FBQUMsV0FBQSxrQkFBQWIsQ0FBQSxRQUFBVSxDQUFBLEdBQUFWLENBQUEsQ0FBQWMsSUFBQSxDQUFBWixDQUFBLEVBQUFELENBQUEsdUNBQUFTLENBQUEsU0FBQUEsQ0FBQSxZQUFBSyxTQUFBLHlFQUFBZCxDQUFBLEdBQUFlLE1BQUEsR0FBQUMsTUFBQSxFQUFBZixDQUFBLEtBUDdDO0FBQ0E7QUFDQTtBQUNBO0FBa0JBLE1BQU1nQixhQUFhLEdBQUcsZ0JBQWdCO0FBRXRDLE1BQU1DLGNBQTZCLEdBQUc7RUFDcENDLE9BQU8sRUFBRSxLQUFLO0VBQ2RDLFNBQVMsRUFBRSxFQUFFO0VBQ2JDLGdCQUFnQixFQUFFLENBQUM7RUFDbkJDLGdCQUFnQixFQUFFLElBQUk7RUFDdEJDLGdCQUFnQixFQUFFLE9BQU87RUFDekJDLFdBQVcsRUFBRSxJQUFJO0VBQ2pCQyx3QkFBd0IsRUFBRSxJQUFJO0VBQzlCQyxhQUFhLEVBQUUsQ0FBQztFQUNoQkMsVUFBVSxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztBQUNyQyxDQUFDO0FBRU0sTUFBTUMsY0FBYyxDQUFDO0VBSTFCOztFQUVBLGFBQWFDLGlCQUFpQkEsQ0FBQ0MsTUFBVyxFQUFpQjtJQUN6RCxJQUFJO01BQ0YsTUFBTTtRQUFFQztNQUFLLENBQUMsR0FBRyxNQUFNRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDO1FBQUVDLEtBQUssRUFBRUM7TUFBcUIsQ0FBQyxDQUFDO01BQzdFLElBQUksQ0FBQ0osSUFBSSxFQUFFO1FBQ1QsTUFBTUQsTUFBTSxDQUFDRSxPQUFPLENBQUNJLE1BQU0sQ0FBQztVQUMxQkYsS0FBSyxFQUFFQywrQkFBb0I7VUFDM0JKLElBQUksRUFBRTtZQUNKTSxRQUFRLEVBQUU7Y0FBRUMsZ0JBQWdCLEVBQUUsQ0FBQztjQUFFQyxrQkFBa0IsRUFBRTtZQUFFLENBQUM7WUFDeERDLFFBQVEsRUFBRTtjQUNSQyxVQUFVLEVBQUU7Z0JBQ1Z4QixPQUFPLEVBQUU7a0JBQUV5QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDNUJ4QixTQUFTLEVBQUU7a0JBQUV3QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDOUJ2QixnQkFBZ0IsRUFBRTtrQkFBRXVCLElBQUksRUFBRTtnQkFBVSxDQUFDO2dCQUNyQ3RCLGdCQUFnQixFQUFFO2tCQUFFc0IsSUFBSSxFQUFFO2dCQUFVLENBQUM7Z0JBQ3JDckIsZ0JBQWdCLEVBQUU7a0JBQUVxQixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDckNwQixXQUFXLEVBQUU7a0JBQUVvQixJQUFJLEVBQUU7Z0JBQU8sQ0FBQztnQkFDN0JuQix3QkFBd0IsRUFBRTtrQkFBRW1CLElBQUksRUFBRTtnQkFBTyxDQUFDO2dCQUMxQ2xCLGFBQWEsRUFBRTtrQkFBRWtCLElBQUksRUFBRTtnQkFBTyxDQUFDO2dCQUMvQmpCLFVBQVUsRUFBRTtrQkFBRWlCLElBQUksRUFBRTtnQkFBTztjQUM3QjtZQUNGO1VBQ0Y7UUFDRixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUMsQ0FBQyxPQUFPN0MsQ0FBQyxFQUFFLENBQUM7RUFDZjtFQUVBLGFBQWE4QyxTQUFTQSxDQUFDYixNQUFXLEVBQTBCO0lBQzFELElBQUk7TUFDRixNQUFNO1FBQUVDO01BQUssQ0FBQyxHQUFHLE1BQU1ELE1BQU0sQ0FBQ2MsR0FBRyxDQUFDO1FBQUVWLEtBQUssRUFBRUMsK0JBQW9CO1FBQUVVLEVBQUUsRUFBRTlCO01BQWMsQ0FBQyxDQUFDO01BQ3JGLE9BQU9nQixJQUFJLENBQUNlLE9BQU87SUFDckIsQ0FBQyxDQUFDLE9BQU9qRCxDQUFNLEVBQUU7TUFBQSxJQUFBa0QsT0FBQTtNQUNmLElBQUksQ0FBQWxELENBQUMsYUFBREEsQ0FBQyx1QkFBREEsQ0FBQyxDQUFFbUQsVUFBVSxNQUFLLEdBQUcsSUFBSSxDQUFBbkQsQ0FBQyxhQUFEQSxDQUFDLGdCQUFBa0QsT0FBQSxHQUFEbEQsQ0FBQyxDQUFFb0QsSUFBSSxjQUFBRixPQUFBLHVCQUFQQSxPQUFBLENBQVNDLFVBQVUsTUFBSyxHQUFHLEVBQUU7UUFDeEQsT0FBTztVQUFFLEdBQUdoQztRQUFlLENBQUM7TUFDOUI7TUFDQSxNQUFNbkIsQ0FBQztJQUNUO0VBQ0Y7RUFFQSxhQUFhcUQsVUFBVUEsQ0FBQ3BCLE1BQVcsRUFBRXFCLE9BQStCLEVBQTBCO0lBQzVGLE1BQU1DLFFBQVEsR0FBRyxNQUFNeEIsY0FBYyxDQUFDZSxTQUFTLENBQUNiLE1BQU0sQ0FBQztJQUN2RCxNQUFNdUIsTUFBcUIsR0FBRztNQUFFLEdBQUdELFFBQVE7TUFBRSxHQUFHRCxPQUFPO01BQUUxQixVQUFVLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDO0lBQUUsQ0FBQztJQUMvRixNQUFNRyxNQUFNLENBQUNJLEtBQUssQ0FBQztNQUNqQkEsS0FBSyxFQUFFQywrQkFBb0I7TUFDM0JVLEVBQUUsRUFBRTlCLGFBQWE7TUFDakJnQixJQUFJLEVBQUVzQixNQUFNO01BQ1pDLE9BQU8sRUFBRTtJQUNYLENBQUMsQ0FBQztJQUNGLE9BQU9ELE1BQU07RUFDZjs7RUFFQTs7RUFFQSxPQUFPRSxLQUFLQSxDQUFDekIsTUFBVyxFQUFFMEIsTUFBYyxFQUFRO0lBQzlDLElBQUk1QixjQUFjLENBQUM2QixjQUFjLEVBQUU7SUFDbkM3QixjQUFjLENBQUM2QixjQUFjLEdBQUdDLFdBQVcsQ0FBQyxZQUFZO01BQ3RELElBQUk7UUFDRixNQUFNOUIsY0FBYyxDQUFDK0IsSUFBSSxDQUFDN0IsTUFBTSxFQUFFMEIsTUFBTSxDQUFDO01BQzNDLENBQUMsQ0FBQyxPQUFPM0QsQ0FBTSxFQUFFO1FBQ2YyRCxNQUFNLENBQUNJLElBQUksQ0FBRSx1QkFBc0IvRCxDQUFDLENBQUNnRSxPQUFRLEVBQUMsQ0FBQztNQUNqRDtJQUNGLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDVkwsTUFBTSxDQUFDTSxJQUFJLENBQUMsMERBQTBELENBQUM7RUFDekU7RUFFQSxPQUFPQyxJQUFJQSxDQUFBLEVBQVM7SUFDbEIsSUFBSW5DLGNBQWMsQ0FBQzZCLGNBQWMsRUFBRTtNQUNqQ08sYUFBYSxDQUFDcEMsY0FBYyxDQUFDNkIsY0FBYyxDQUFDO01BQzVDN0IsY0FBYyxDQUFDNkIsY0FBYyxHQUFHLElBQUk7SUFDdEM7RUFDRjtFQUVBLGFBQWFFLElBQUlBLENBQUM3QixNQUFXLEVBQUUwQixNQUFjLEVBQWlCO0lBQzVELE1BQU1TLE1BQU0sR0FBRyxNQUFNckMsY0FBYyxDQUFDZSxTQUFTLENBQUNiLE1BQU0sQ0FBQztJQUNyRCxJQUFJLENBQUNtQyxNQUFNLENBQUNoRCxPQUFPLEVBQUU7SUFFckIsTUFBTWlELEdBQUcsR0FBR3hDLElBQUksQ0FBQ3dDLEdBQUcsQ0FBQyxDQUFDO0lBQ3RCLE1BQU1DLFVBQVUsR0FBRyxDQUFDRixNQUFNLENBQUM5QyxnQkFBZ0IsSUFBSSxDQUFDLElBQUksTUFBTTtJQUMxRCxNQUFNaUQsT0FBTyxHQUFHSCxNQUFNLENBQUMzQyxXQUFXLEdBQUcsSUFBSUksSUFBSSxDQUFDdUMsTUFBTSxDQUFDM0MsV0FBVyxDQUFDLENBQUMrQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7SUFDL0UsSUFBSUgsR0FBRyxHQUFHRSxPQUFPLEdBQUdELFVBQVUsRUFBRTtJQUVoQyxJQUFJdkMsY0FBYyxDQUFDMEMsT0FBTyxFQUFFO0lBQzVCMUMsY0FBYyxDQUFDMEMsT0FBTyxHQUFHLElBQUk7SUFFN0IsSUFBSTtNQUNGZCxNQUFNLENBQUNNLElBQUksQ0FBRSw0Q0FBMkNHLE1BQU0sQ0FBQy9DLFNBQVUsV0FBVStDLE1BQU0sQ0FBQzFDLHdCQUF3QixJQUFJLFdBQVksRUFBQyxDQUFDO01BQ3BJLE1BQU1nRCxPQUFPLEdBQUcsTUFBTTNDLGNBQWMsQ0FBQzRDLGtCQUFrQixDQUFDMUMsTUFBTSxFQUFFbUMsTUFBTSxFQUFFVCxNQUFNLENBQUM7TUFDL0UsTUFBTTVCLGNBQWMsQ0FBQ3NCLFVBQVUsQ0FBQ3BCLE1BQU0sRUFBRTtRQUN0Q1IsV0FBVyxFQUFFLElBQUlJLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1FBQ3JDSCxhQUFhLEVBQUUsQ0FBQ3lDLE1BQU0sQ0FBQ3pDLGFBQWEsSUFBSSxDQUFDLElBQUkrQztNQUMvQyxDQUFDLENBQUM7TUFDRmYsTUFBTSxDQUFDTSxJQUFJLENBQUUsb0NBQW1DUyxPQUFRLEVBQUMsQ0FBQztJQUM1RCxDQUFDLFNBQVM7TUFDUjNDLGNBQWMsQ0FBQzBDLE9BQU8sR0FBRyxLQUFLO0lBQ2hDO0VBQ0Y7O0VBRUE7O0VBRUEsYUFBYUUsa0JBQWtCQSxDQUM3QjFDLE1BQVcsRUFDWG1DLE1BQXFCLEVBQ3JCVCxNQUFjLEVBQ0c7SUFDakI7SUFDQSxNQUFNaUIsS0FBSyxHQUFHUixNQUFNLENBQUMxQyx3QkFBd0IsSUFDeEMsSUFBSUcsSUFBSSxDQUFDQSxJQUFJLENBQUN3QyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUN2QyxXQUFXLENBQUMsQ0FBQzs7SUFFMUQ7SUFDQTtJQUNBLE1BQU0rQyxVQUFVLEdBQUc7TUFDakJDLEtBQUssRUFBRTtRQUNMQyxJQUFJLEVBQUU7VUFDSkMsSUFBSSxFQUFFLENBQ0o7WUFBRUMsS0FBSyxFQUFFO2NBQUUsWUFBWSxFQUFFO2dCQUFFQyxHQUFHLEVBQUVqRSxNQUFNLENBQUNtRCxNQUFNLENBQUMvQyxTQUFTO2NBQUU7WUFBRTtVQUFFLENBQUMsQ0FDL0Q7VUFDRDhELE1BQU0sRUFBRSxDQUNOO1lBQUVGLEtBQUssRUFBRTtjQUFFRyxTQUFTLEVBQUk7Z0JBQUVDLEVBQUUsRUFBRVQ7Y0FBTTtZQUFFO1VBQUUsQ0FBQyxFQUN6QztZQUFFSyxLQUFLLEVBQUU7Y0FBRSxZQUFZLEVBQUU7Z0JBQUVJLEVBQUUsRUFBRVQ7Y0FBTTtZQUFFO1VBQUUsQ0FBQyxDQUMzQztVQUNEVSxvQkFBb0IsRUFBRTtRQUN4QjtNQUNGLENBQUM7TUFDREMsSUFBSSxFQUFFLENBQ0o7UUFBRUgsU0FBUyxFQUFFO1VBQUVJLEtBQUssRUFBRSxLQUFLO1VBQUVDLGFBQWEsRUFBRTtRQUFPO01BQUUsQ0FBQyxDQUN2RDtNQUNEQyxJQUFJLEVBQUU7SUFDUixDQUFDO0lBRUQsSUFBSUMsSUFBVyxHQUFHLEVBQUU7SUFDcEIsSUFBSTtNQUFBLElBQUFDLFlBQUE7TUFDRixNQUFNO1FBQUUxRCxJQUFJLEVBQUUyRDtNQUFPLENBQUMsR0FBRyxNQUFNNUQsTUFBTSxDQUFDNkQsTUFBTSxDQUFDO1FBQzNDekQsS0FBSyxFQUFFMEQscUNBQTBCO1FBQ2pDN0QsSUFBSSxFQUFFMkMsVUFBVTtRQUNoQm1CLGtCQUFrQixFQUFFO01BQ3RCLENBQUMsQ0FBQztNQUNGTCxJQUFJLEdBQUcsRUFBQUMsWUFBQSxHQUFBQyxNQUFNLENBQUNGLElBQUksY0FBQUMsWUFBQSx1QkFBWEEsWUFBQSxDQUFhRCxJQUFJLEtBQUksRUFBRTtNQUM5QmhDLE1BQU0sQ0FBQ00sSUFBSSxDQUFFLHVCQUFzQjBCLElBQUksQ0FBQ00sTUFBTywyQkFBMEI3QixNQUFNLENBQUMvQyxTQUFVLFVBQVN1RCxLQUFNLEVBQUMsQ0FBQztJQUM3RyxDQUFDLENBQUMsT0FBTzVFLENBQU0sRUFBRTtNQUNmMkQsTUFBTSxDQUFDSSxJQUFJLENBQUUsdUNBQXNDL0QsQ0FBQyxDQUFDZ0UsT0FBUSxFQUFDLENBQUM7TUFDL0QsT0FBTyxDQUFDO0lBQ1Y7SUFFQSxJQUFJMkIsSUFBSSxDQUFDTSxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQ3JCLE1BQU1sRSxjQUFjLENBQUNzQixVQUFVLENBQUNwQixNQUFNLEVBQUU7UUFDdENQLHdCQUF3QixFQUFFLElBQUlHLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztNQUNuRCxDQUFDLENBQUM7TUFDRixPQUFPLENBQUM7SUFDVjtJQUVBLElBQUk0QyxPQUFPLEdBQUcsQ0FBQztJQUNmLElBQUl3QixlQUFlLEdBQUd0QixLQUFLOztJQUUzQjtJQUNBO0lBQ0EsTUFBTXVCLGdCQUFnQixHQUFHLE1BQU1wRSxjQUFjLENBQUNxRSw4QkFBOEIsQ0FBQ25FLE1BQU0sRUFBRTBCLE1BQU0sQ0FBQztJQUU1RixLQUFLLE1BQU0wQyxHQUFHLElBQUlWLElBQUksRUFBRTtNQUFBLElBQUFXLFdBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUE7TUFDdEIsTUFBTUMsS0FBSyxHQUFHTCxHQUFHLENBQUNwRCxPQUFPO01BQ3pCLE1BQU0wRCxPQUFPLEdBQUdOLEdBQUcsQ0FBQ08sR0FBRzs7TUFFdkI7TUFDQSxNQUFNQyxjQUFzQixHQUMxQixDQUFBSCxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRXRCLFNBQVMsTUFBSXNCLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFHLFlBQVksQ0FBQyxLQUFJLElBQUk3RSxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztNQUV2RSxJQUFJK0UsY0FBYyxHQUFHWCxlQUFlLEVBQUVBLGVBQWUsR0FBR1csY0FBYzs7TUFFdEU7TUFDQSxJQUFJVixnQkFBZ0IsQ0FBQ1csR0FBRyxDQUFDSCxPQUFPLENBQUMsRUFBRTtRQUNqQ2hELE1BQU0sQ0FBQ00sSUFBSSxDQUFFLHVCQUFzQjBDLE9BQVEsNEJBQTJCLENBQUM7UUFDdkU7TUFDRjtNQUVBLE1BQU1JLGVBQWUsR0FBRyxDQUFBTCxLQUFLLGFBQUxBLEtBQUssZ0JBQUFKLFdBQUEsR0FBTEksS0FBSyxDQUFFTSxJQUFJLGNBQUFWLFdBQUEsdUJBQVhBLFdBQUEsQ0FBYVcsV0FBVyxLQUFJLGdCQUFnQjtNQUNwRSxNQUFNQyxTQUFTLEdBQVNqRyxNQUFNLENBQUN5RixLQUFLLGFBQUxBLEtBQUssZ0JBQUFILFlBQUEsR0FBTEcsS0FBSyxDQUFFTSxJQUFJLGNBQUFULFlBQUEsdUJBQVhBLFlBQUEsQ0FBYVksS0FBSyxDQUFDLElBQUksQ0FBQztNQUN2RCxNQUFNQyxNQUFNLEdBQVlwRyxNQUFNLENBQUMsQ0FBQTBGLEtBQUssYUFBTEEsS0FBSyxnQkFBQUYsWUFBQSxHQUFMRSxLQUFLLENBQUVNLElBQUksY0FBQVIsWUFBQSx1QkFBWEEsWUFBQSxDQUFheEQsRUFBRSxLQUFJLEVBQUUsQ0FBQztNQUNyRCxNQUFNcUUsT0FBTyxHQUFXckcsTUFBTSxDQUFDLENBQUEwRixLQUFLLGFBQUxBLEtBQUssZ0JBQUFELFlBQUEsR0FBTEMsS0FBSyxDQUFFWSxLQUFLLGNBQUFiLFlBQUEsdUJBQVpBLFlBQUEsQ0FBY3pELEVBQUUsS0FBSSxFQUFFLENBQUM7TUFFdEQsSUFBSTtRQUFBLElBQUF1RSxnQkFBQTtRQUNGLElBQUlDLFFBQVEsR0FBRyxLQUFLO1FBQ3BCLElBQUlOLFNBQVMsSUFBSSxFQUFFLEVBQUVNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FDdEMsSUFBSU4sU0FBUyxJQUFJLEVBQUUsRUFBRU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUN2QyxJQUFJTixTQUFTLElBQUksQ0FBQyxFQUFHTSxRQUFRLEdBQUcsUUFBUTtRQUU3QyxNQUFNQyxPQUFPLEdBQUcsTUFBTUMseUJBQVcsQ0FBQ0MsVUFBVSxDQUMxQzFGLE1BQU0sRUFDTjtVQUNFMkYsS0FBSyxFQUFFLGFBQWE7VUFDcEJYLFdBQVcsRUFBRWxGLGNBQWMsQ0FBQzhGLGdCQUFnQixDQUFDbkIsS0FBSyxFQUFFTCxHQUFHLENBQUN5QixNQUFNLENBQUM7VUFDL0ROLFFBQVEsRUFBRUEsUUFBZTtVQUN6Qk8sUUFBUSxFQUFFM0QsTUFBTSxDQUFDN0MsZ0JBQXVCO1VBQ3hDeUcsUUFBUSxFQUFFNUQsTUFBTSxDQUFDNUMsZ0JBQXVCO1VBQ3hDeUcsSUFBSSxFQUFFLENBQUMsY0FBYyxFQUFHLFNBQVFmLFNBQVUsRUFBQyxFQUFFLElBQUlFLE1BQU0sR0FBRyxDQUFFLFFBQU9BLE1BQU8sRUFBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3BGLENBQUMsRUFDRCxjQUNGLENBQUM7UUFFRCxNQUFNYyxTQUFTLEdBQVFULE9BQU8sQ0FBQ3pFLEVBQUc7UUFDbEMsTUFBTW1GLGFBQWEsR0FBSSxFQUFBWixnQkFBQSxHQUFBRSxPQUFPLENBQUNXLE9BQU8sY0FBQWIsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCYyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEtBQUksTUFBTTtRQUNsRSxNQUFNQyxXQUFXLEdBQU8sY0FBYUosYUFBYyxLQUFJcEIsZUFBZ0IsRUFBQztRQUN4RSxNQUFNeUIsV0FBVyxHQUFNekcsY0FBYyxDQUFDMEcsZ0JBQWdCLENBQUNwQyxHQUFHLENBQUM7UUFFM0QsTUFBTXBFLE1BQU0sQ0FBQ3lHLE1BQU0sQ0FBQztVQUNsQnJHLEtBQUssRUFBRXNHLHFCQUFVO1VBQ2pCM0YsRUFBRSxFQUFFa0YsU0FBUztVQUNiaEcsSUFBSSxFQUFFO1lBQ0owRyxHQUFHLEVBQUU7Y0FDSGhCLEtBQUssRUFBRVcsV0FBVztjQUNsQk0sYUFBYSxFQUFFLENBQUNMLFdBQVcsQ0FBQztjQUM1QjtjQUNBUCxJQUFJLEVBQUUsQ0FBQyxjQUFjLEVBQUcsU0FBUWYsU0FBVSxFQUFDLEVBQUcsY0FBYVAsT0FBUSxFQUFDLENBQUM7Y0FDckUvRSxVQUFVLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDO1lBQ3JDO1VBQ0YsQ0FBQztVQUNEZ0gsaUJBQWlCLEVBQUU7UUFDckIsQ0FBQyxDQUFDOztRQUVGO1FBQ0EzQyxnQkFBZ0IsQ0FBQzRDLEdBQUcsQ0FBQ3BDLE9BQU8sQ0FBQztRQUU3QmpDLE9BQU8sRUFBRTtRQUNUZixNQUFNLENBQUNNLElBQUksQ0FBRSx5QkFBd0JzRSxXQUFZLEVBQUMsQ0FBQztNQUNyRCxDQUFDLENBQUMsT0FBT3ZJLENBQU0sRUFBRTtRQUNmMkQsTUFBTSxDQUFDSSxJQUFJLENBQUUseUNBQXdDNEMsT0FBUSxNQUFLM0csQ0FBQyxDQUFDZ0UsT0FBUSxFQUFDLENBQUM7TUFDaEY7SUFDRjtJQUVBLE1BQU1qQyxjQUFjLENBQUNzQixVQUFVLENBQUNwQixNQUFNLEVBQUU7TUFDdENQLHdCQUF3QixFQUFFd0U7SUFDNUIsQ0FBQyxDQUFDO0lBRUYsT0FBT3hCLE9BQU87RUFDaEI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRSxhQUFxQjBCLDhCQUE4QkEsQ0FDakRuRSxNQUFXLEVBQ1gwQixNQUFjLEVBQ1E7SUFDdEIsTUFBTXFGLEdBQUcsR0FBRyxJQUFJQyxHQUFHLENBQVMsQ0FBQztJQUM3QixJQUFJO01BQ0YsTUFBTTtRQUFFL0csSUFBSSxFQUFFMkQ7TUFBTyxDQUFDLEdBQUcsTUFBTTVELE1BQU0sQ0FBQzZELE1BQU0sQ0FBQztRQUMzQ3pELEtBQUssRUFBRXNHLHFCQUFVO1FBQ2pCekcsSUFBSSxFQUFFO1VBQ0o0QyxLQUFLLEVBQUU7WUFDTEMsSUFBSSxFQUFFO2NBQ0pDLElBQUksRUFBRSxDQUNKO2dCQUFFa0UsS0FBSyxFQUFFO2tCQUFFQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsYUFBYSxFQUFFLFNBQVM7Z0JBQUU7Y0FBRSxDQUFDLEVBQ3pEO2dCQUFFQyxJQUFJLEVBQUU7a0JBQUVuQixJQUFJLEVBQUU7Z0JBQWU7Y0FBRSxDQUFDO1lBRXRDO1VBQ0YsQ0FBQztVQUNEaEYsT0FBTyxFQUFFLENBQUMsZUFBZSxDQUFDO1VBQzFCeUMsSUFBSSxFQUFFO1FBQ1I7TUFDRixDQUFDLENBQUM7TUFDRixLQUFLLE1BQU1XLEdBQUcsSUFBSyxFQUFBZ0QsYUFBQSxHQUFBeEQsTUFBTSxDQUFDRixJQUFJLGNBQUEwRCxhQUFBLHVCQUFYQSxhQUFBLENBQWExRCxJQUFJLEtBQUksRUFBRSxFQUFHO1FBQUEsSUFBQTBELGFBQUE7UUFDM0MsS0FBSyxNQUFNQyxFQUFFLElBQUssRUFBQUMsWUFBQSxHQUFBbEQsR0FBRyxDQUFDcEQsT0FBTyxjQUFBc0csWUFBQSx1QkFBWEEsWUFBQSxDQUFhVixhQUFhLEtBQUksRUFBRSxFQUFHO1VBQUEsSUFBQVUsWUFBQTtVQUNuRCxJQUFJRCxFQUFFLENBQUNFLFFBQVEsRUFBRVIsR0FBRyxDQUFDRCxHQUFHLENBQUNPLEVBQUUsQ0FBQ0UsUUFBUSxDQUFDO1FBQ3ZDO01BQ0Y7SUFDRixDQUFDLENBQUMsT0FBT3hKLENBQU0sRUFBRTtNQUNmMkQsTUFBTSxDQUFDSSxJQUFJLENBQUUsdURBQXNEL0QsQ0FBQyxDQUFDZ0UsT0FBUSxFQUFDLENBQUM7SUFDakY7SUFDQSxPQUFPZ0YsR0FBRztFQUNaO0VBRUEsT0FBZVAsZ0JBQWdCQSxDQUFDcEMsR0FBUSxFQUFPO0lBQUEsSUFBQW9ELFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBO0lBQzdDLE1BQU1wRCxLQUFLLEdBQUdMLEdBQUcsQ0FBQ3BELE9BQU87SUFDekIsT0FBTztNQUNMdUcsUUFBUSxFQUFVbkQsR0FBRyxDQUFDTyxHQUFHO01BQ3pCdkUsS0FBSyxFQUFhZ0UsR0FBRyxDQUFDeUIsTUFBTSxJQUFJL0IscUNBQTBCO01BQzFEZ0UsT0FBTyxFQUFXQyxRQUFRLENBQUMsQ0FBQXRELEtBQUssYUFBTEEsS0FBSyxnQkFBQStDLFlBQUEsR0FBTC9DLEtBQUssQ0FBRU0sSUFBSSxjQUFBeUMsWUFBQSx1QkFBWEEsWUFBQSxDQUFhekcsRUFBRSxLQUFJLEdBQUcsRUFBRSxFQUFFLENBQUM7TUFDdERpSCxnQkFBZ0IsRUFBRSxDQUFBdkQsS0FBSyxhQUFMQSxLQUFLLGdCQUFBZ0QsWUFBQSxHQUFMaEQsS0FBSyxDQUFFTSxJQUFJLGNBQUEwQyxZQUFBLHVCQUFYQSxZQUFBLENBQWF6QyxXQUFXLEtBQUksRUFBRTtNQUNoRGlELFVBQVUsRUFBUSxDQUFBeEQsS0FBSyxhQUFMQSxLQUFLLGdCQUFBaUQsWUFBQSxHQUFMakQsS0FBSyxDQUFFTSxJQUFJLGNBQUEyQyxZQUFBLHVCQUFYQSxZQUFBLENBQWF4QyxLQUFLLEtBQUksQ0FBQztNQUN6Q2dELFdBQVcsRUFBTyxDQUFBekQsS0FBSyxhQUFMQSxLQUFLLGdCQUFBa0QsWUFBQSxHQUFMbEQsS0FBSyxDQUFFTSxJQUFJLGNBQUE0QyxZQUFBLHVCQUFYQSxZQUFBLENBQWFRLE1BQU0sS0FBSSxFQUFFO01BQzNDQyxRQUFRLEVBQVUsQ0FBQTNELEtBQUssYUFBTEEsS0FBSyxnQkFBQW1ELGFBQUEsR0FBTG5ELEtBQUssQ0FBRVksS0FBSyxjQUFBdUMsYUFBQSx1QkFBWkEsYUFBQSxDQUFjN0csRUFBRSxLQUFJLEVBQUU7TUFDeENzSCxVQUFVLEVBQVEsQ0FBQTVELEtBQUssYUFBTEEsS0FBSyxnQkFBQW9ELGFBQUEsR0FBTHBELEtBQUssQ0FBRVksS0FBSyxjQUFBd0MsYUFBQSx1QkFBWkEsYUFBQSxDQUFjUyxJQUFJLEtBQUksRUFBRTtNQUMxQ25GLFNBQVMsRUFBUyxDQUFBc0IsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUV0QixTQUFTLE1BQUlzQixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRyxZQUFZLENBQUMsS0FBSSxJQUFJN0UsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFDdkYwSSxRQUFRLEVBQVUsQ0FBQTlELEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFOEQsUUFBUSxLQUFJO0lBQ3ZDLENBQUM7RUFDSDtFQUVBLE9BQWUzQyxnQkFBZ0JBLENBQUNuQixLQUFVLEVBQUVyRSxLQUFhLEVBQVU7SUFBQSxJQUFBb0ksWUFBQSxFQUFBQyxZQUFBLEVBQUFDLGlCQUFBLEVBQUFDLGFBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBLEVBQUFDLGFBQUE7SUFDakUsTUFBTTNELE1BQU0sR0FBTSxDQUFBVixLQUFLLGFBQUxBLEtBQUssZ0JBQUErRCxZQUFBLEdBQUwvRCxLQUFLLENBQUVNLElBQUksY0FBQXlELFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXpILEVBQUUsS0FBSSxLQUFLO0lBQzFDLE1BQU1nSSxRQUFRLEdBQUksQ0FBQXRFLEtBQUssYUFBTEEsS0FBSyxnQkFBQWdFLFlBQUEsR0FBTGhFLEtBQUssQ0FBRU0sSUFBSSxjQUFBMEQsWUFBQSx1QkFBWEEsWUFBQSxDQUFhekQsV0FBVyxLQUFJLEtBQUs7SUFDbkQsTUFBTUMsU0FBUyxJQUFBeUQsaUJBQUEsR0FBR2pFLEtBQUssYUFBTEEsS0FBSyxnQkFBQWtFLGFBQUEsR0FBTGxFLEtBQUssQ0FBRU0sSUFBSSxjQUFBNEQsYUFBQSx1QkFBWEEsYUFBQSxDQUFhekQsS0FBSyxjQUFBd0QsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxLQUFLO0lBQzdDLE1BQU1NLFNBQVMsR0FBRyxDQUFBdkUsS0FBSyxhQUFMQSxLQUFLLGdCQUFBbUUsYUFBQSxHQUFMbkUsS0FBSyxDQUFFWSxLQUFLLGNBQUF1RCxhQUFBLHVCQUFaQSxhQUFBLENBQWNOLElBQUksS0FBSSxTQUFTO0lBQ2pELE1BQU1sRCxPQUFPLEdBQUssQ0FBQVgsS0FBSyxhQUFMQSxLQUFLLGdCQUFBb0UsYUFBQSxHQUFMcEUsS0FBSyxDQUFFWSxLQUFLLGNBQUF3RCxhQUFBLHVCQUFaQSxhQUFBLENBQWM5SCxFQUFFLEtBQUksS0FBSztJQUMzQyxNQUFNb0gsTUFBTSxHQUFNLENBQUMsQ0FBQTFELEtBQUssYUFBTEEsS0FBSyxnQkFBQXFFLGFBQUEsR0FBTHJFLEtBQUssQ0FBRU0sSUFBSSxjQUFBK0QsYUFBQSx1QkFBWEEsYUFBQSxDQUFhWCxNQUFNLEtBQUksRUFBRSxFQUFFYyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSztJQUNqRSxNQUFNQyxLQUFLLEdBQU8sQ0FBQXpFLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFdEIsU0FBUyxNQUFJc0IsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUcsWUFBWSxDQUFDO0lBQzNELE1BQU10QixTQUFTLEdBQUcrRixLQUFLLEdBQ25CLElBQUl0SixJQUFJLENBQUNzSixLQUFLLENBQUMsQ0FBQ0MsY0FBYyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxTQUFTLEVBQUUsUUFBUTtNQUFFQyxTQUFTLEVBQUU7SUFBUyxDQUFDLENBQUMsR0FDckYsS0FBSztJQUVULE1BQU1DLEtBQWUsR0FBRyxDQUNyQixnRUFBK0QsRUFDL0QsRUFBQyxFQUNELGtCQUFpQixFQUNqQixFQUFDLEVBQ0Qsa0JBQWlCbkUsTUFBTyxFQUFDLEVBQ3pCLHNCQUFxQjRELFFBQVMsRUFBQyxFQUMvQixnQkFBZTlELFNBQVUsRUFBQyxFQUMxQixpQkFBZ0JrRCxNQUFPLEVBQUMsRUFDeEIsZ0JBQWVhLFNBQVUsU0FBUTVELE9BQVEsR0FBRSxFQUMzQyxtQkFBa0JqQyxTQUFVLEVBQUMsQ0FDL0I7SUFFRCxJQUFJc0IsS0FBSyxhQUFMQSxLQUFLLGVBQUxBLEtBQUssQ0FBRThELFFBQVEsRUFBRTtNQUNuQixNQUFNZ0IsR0FBRyxHQUFHeEssTUFBTSxDQUFDMEYsS0FBSyxDQUFDOEQsUUFBUSxDQUFDLENBQUNpQixJQUFJLENBQUMsQ0FBQyxDQUFDQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztNQUMzREgsS0FBSyxDQUFDSSxJQUFJLENBQUUsRUFBQyxFQUFHLFlBQVcsRUFBRyxFQUFDLEVBQUcsUUFBTyxFQUFFSCxHQUFHLEVBQUcsUUFBTyxDQUFDO0lBQzNEO0lBRUEsT0FBT0QsS0FBSyxDQUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3pCO0FBQ0Y7QUFBQ1UsT0FBQSxDQUFBN0osY0FBQSxHQUFBQSxjQUFBO0FBQUFoQyxlQUFBLENBcFVZZ0MsY0FBYyxvQkFDOEMsSUFBSTtBQUFBaEMsZUFBQSxDQURoRWdDLGNBQWMsYUFFQSxLQUFLIn0=